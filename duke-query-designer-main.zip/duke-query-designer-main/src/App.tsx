import { useState } from 'react'
import { QueryList } from './components/QueryList'
import { QueryEditor } from './components/editor/QueryEditor'
import type { QueryRecord } from './types/query'

type View = { page: 'list' } | { page: 'editor'; record: QueryRecord | null }

export default function App() {
  const [view, setView] = useState<View>({ page: 'list' })
  if (view.page === 'editor') {
    return (
      <QueryEditor
        record={view.record}
        onBack={() => setView({ page: 'list' })}
        onSaved={record => {
          setView(v => v.page === 'editor' ? { ...v, record } : v)
        }}
      />
    )
  }

  return (
    <QueryList
      onOpen={record => setView({ page: 'editor', record })}
    />
  )
}
